package com.survivalplus;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;

public class SurvivalPlus extends JavaPlugin implements Listener {

    private static final String TAG = "survivalplus_display";
    private static final String NETA_PREFIX = "§cNeta §r";
    private static final String SB_PREFIX = "sp_";
    private static final String DISCORD_DEFAULT = "https://discord.gg/ccYUmyTPsc";
    private static final Pattern TEAM_NAME = Pattern.compile("[A-Za-z0-9_]{3,12}");
    private static final Pattern HOME_NAME = Pattern.compile("[A-Za-z0-9_-]{1,16}");
    private static final long INVITE_TTL_MS = 60_000L;

    // ---- player state ----
    private final Set<UUID> viewers = new HashSet<>();      // /indicator ON
    private final Set<UUID> nvPlayers = new HashSet<>();    // /nightvision ON
    private final Set<UUID> netas = new HashSet<>();        // Neta rank

    // ---- homes ----
    private final Map<UUID, Map<String, Home>> homes = new HashMap<>();
    private final Map<UUID, Long> lastHome = new HashMap<>();

    // ---- teams ----
    private final Map<String, TeamData> teams = new LinkedHashMap<>(); // key = lowercase name
    private final Map<UUID, String> playerTeam = new HashMap<>();      // player -> team key
    private final Map<UUID, Invite> invites = new HashMap<>();

    // ---- HUD ----
    private final Map<String, Holder> holders = new HashMap<>();

    // ---- settings (config.yml) ----
    private int maxHomes, netaMaxHomes, teamMaxHomes;
    private long cooldownMs;
    private boolean showPlayerHearts, showMobHearts, showHotbar, onlyDamaged;
    private double radius;
    private int period;
    private float viewRange, playerHeartsY, hotbarY, mobHeartsY;

    private File dataFile, playersFile;
    private BukkitTask hudTask, nvTask;

    // =====================================================================
    //  Lifecycle
    // =====================================================================

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getDataFolder().mkdirs();
        dataFile = new File(getDataFolder(), "data.yml");
        playersFile = new File(getDataFolder(), "players.yml");

        reloadSettings();
        loadData();
        loadPlayers();
        cleanupStray();

        getServer().getPluginManager().registerEvents(this, this);
        hudTask = Bukkit.getScheduler().runTaskTimer(this, this::hudTick, 20L, period);
        nvTask = Bukkit.getScheduler().runTaskTimer(this, this::nightVisionTick, 20L, 40L);

        for (Player p : Bukkit.getOnlinePlayers()) refreshPlayer(p);
        getLogger().info("SurvivalPlus enabled.");
    }

    @Override
    public void onDisable() {
        if (hudTask != null) hudTask.cancel();
        if (nvTask != null) nvTask.cancel();
        removeAllHolders();
        cleanupStray();
        saveData();
        savePlayers();
    }

    private void reloadSettings() {
        var c = getConfig();
        maxHomes = c.getInt("max-homes", 3);
        netaMaxHomes = c.getInt("neta-max-homes", 5);
        teamMaxHomes = c.getInt("team-max-homes", 3);
        cooldownMs = c.getLong("home-cooldown-minutes", 10L) * 60_000L;

        showPlayerHearts = c.getBoolean("show-player-hearts", true);
        showMobHearts = c.getBoolean("show-mob-hearts", true);
        showHotbar = c.getBoolean("show-player-hotbar", true);
        onlyDamaged = c.getBoolean("mob-hearts-only-when-damaged", false);
        radius = c.getDouble("radius", 24.0);
        period = Math.max(1, c.getInt("update-ticks", 2));
        viewRange = (float) c.getDouble("view-range", 0.5);
        playerHeartsY = (float) c.getDouble("player-hearts-height", 0.8);
        hotbarY = (float) c.getDouble("player-hotbar-height", 1.15);
        mobHeartsY = (float) c.getDouble("mob-hearts-height", 0.45);
    }

    // =====================================================================
    //  Persistence
    // =====================================================================

    private void loadData() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);

        ConfigurationSection hs = y.getConfigurationSection("homes");
        if (hs != null) {
            for (String uid : hs.getKeys(false)) {
                UUID u = parseUuid(uid);
                ConfigurationSection sec = hs.getConfigurationSection(uid);
                if (u == null || sec == null) continue;
                Map<String, Home> m = new LinkedHashMap<>();
                for (String hn : sec.getKeys(false)) {
                    Home h = readHome(sec.getConfigurationSection(hn));
                    if (h != null) m.put(hn, h);
                }
                homes.put(u, m);
            }
        }

        ConfigurationSection lh = y.getConfigurationSection("last-home");
        if (lh != null) {
            for (String uid : lh.getKeys(false)) {
                UUID u = parseUuid(uid);
                if (u != null) lastHome.put(u, lh.getLong(uid));
            }
        }

        ConfigurationSection ts = y.getConfigurationSection("teams");
        if (ts != null) {
            for (String key : ts.getKeys(false)) {
                ConfigurationSection t = ts.getConfigurationSection(key);
                if (t == null) continue;
                TeamData td = new TeamData(t.getString("name", key), t.getString("owner", ""));
                try {
                    td.color = ChatColor.valueOf(t.getString("color", "WHITE"));
                } catch (IllegalArgumentException ex) {
                    td.color = ChatColor.WHITE;
                }
                td.admins.addAll(t.getStringList("admins"));
                td.members.addAll(t.getStringList("members"));
                td.allies.addAll(t.getStringList("allies"));
                ConfigurationSection th = t.getConfigurationSection("homes");
                if (th != null) {
                    for (String hn : th.getKeys(false)) {
                        Home h = readHome(th.getConfigurationSection(hn));
                        if (h != null) td.homes.put(hn, h);
                    }
                }
                List<?> raw = t.getList("chest");
                if (raw != null) {
                    td.chest = new ItemStack[54];
                    for (int i = 0; i < Math.min(raw.size(), 54); i++) {
                        Object o = raw.get(i);
                        if (o instanceof ItemStack is) td.chest[i] = is;
                    }
                }
                teams.put(td.key, td);
                for (String m : td.members) {
                    UUID u = parseUuid(m);
                    if (u != null) playerTeam.put(u, td.key);
                }
            }
        }
    }

    private void saveData() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, Map<String, Home>> e : homes.entrySet()) {
            for (Map.Entry<String, Home> h : e.getValue().entrySet()) {
                writeHome(y, "homes." + e.getKey() + "." + h.getKey(), h.getValue());
            }
        }
        for (Map.Entry<UUID, Long> e : lastHome.entrySet()) {
            y.set("last-home." + e.getKey(), e.getValue());
        }
        for (TeamData t : teams.values()) {
            String base = "teams." + t.key;
            y.set(base + ".name", t.name);
            y.set(base + ".owner", t.owner);
            y.set(base + ".color", t.color.name());
            y.set(base + ".admins", new ArrayList<>(t.admins));
            y.set(base + ".members", new ArrayList<>(t.members));
            y.set(base + ".allies", new ArrayList<>(t.allies));
            for (Map.Entry<String, Home> h : t.homes.entrySet()) {
                writeHome(y, base + ".homes." + h.getKey(), h.getValue());
            }
            ItemStack[] snap = t.snapshot();
            if (snap != null) y.set(base + ".chest", Arrays.asList(snap));
        }
        try {
            y.save(dataFile);
        } catch (IOException ex) {
            getLogger().severe("data.yml save nahi hui: " + ex.getMessage());
        }
    }

    private void loadPlayers() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(playersFile);
        readUuids(viewers, y.getStringList("viewers"));
        readUuids(nvPlayers, y.getStringList("nightvision"));
        readUuids(netas, y.getStringList("netas"));
    }

    private void savePlayers() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("viewers", uuidStrings(viewers));
        y.set("nightvision", uuidStrings(nvPlayers));
        y.set("netas", uuidStrings(netas));
        try {
            y.save(playersFile);
        } catch (IOException ex) {
            getLogger().severe("players.yml save nahi hui: " + ex.getMessage());
        }
    }

    private static void readUuids(Set<UUID> target, List<String> raw) {
        for (String s : raw) {
            UUID u = parseUuid(s);
            if (u != null) target.add(u);
        }
    }

    private static List<String> uuidStrings(Set<UUID> set) {
        List<String> out = new ArrayList<>();
        for (UUID u : set) out.add(u.toString());
        return out;
    }

    private static UUID parseUuid(String s) {
        try {
            return UUID.fromString(s);
        } catch (IllegalArgumentException | NullPointerException ex) {
            return null;
        }
    }

    private static void writeHome(YamlConfiguration y, String path, Home h) {
        y.set(path + ".world", h.world());
        y.set(path + ".x", h.x());
        y.set(path + ".y", h.y());
        y.set(path + ".z", h.z());
        y.set(path + ".yaw", (double) h.yaw());
        y.set(path + ".pitch", (double) h.pitch());
    }

    private static Home readHome(ConfigurationSection s) {
        if (s == null) return null;
        String world = s.getString("world");
        if (world == null) return null;
        return new Home(world, s.getDouble("x"), s.getDouble("y"), s.getDouble("z"),
                (float) s.getDouble("yaw"), (float) s.getDouble("pitch"));
    }

    // =====================================================================
    //  Commands
    // =====================================================================

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String name = cmd.getName().toLowerCase(Locale.ROOT);

        if (name.equals("neta")) { handleNeta(sender, args); return true; }
        if (name.equals("discordlink")) { handleDiscordLink(sender, args); return true; }

        if (!(sender instanceof Player p)) {
            sender.sendMessage("Ye command sirf players ke liye hai.");
            return true;
        }

        switch (name) {
            case "sethome" -> setHome(p, args);
            case "home" -> goHome(p, args);
            case "delhome" -> delHome(p, args);
            case "homes" -> listHomes(p);
            case "indicator" -> cmdIndicator(p, args);
            case "nightvision" -> cmdNightVision(p, args);
            case "ec" -> cmdEc(p);
            case "createteam" -> createTeam(p, args);
            case "team" -> handleTeam(p, args);
            default -> { return false; }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        String name = cmd.getName().toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        if (name.equals("team")) {
            if (args.length == 1) {
                for (String s : List.of("help", "info", "invite", "accept", "leave", "kick", "disband",
                        "color", "admin", "enderchest", "sethome", "delhome", "ally")) {
                    if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
                }
            } else if (args.length == 2) {
                String sub = args[0].toLowerCase(Locale.ROOT);
                if (sub.equals("color")) {
                    for (ChatColor c : ChatColor.values()) if (c.isColor()) out.add(c.name().toLowerCase(Locale.ROOT));
                } else if (sub.equals("invite") || sub.equals("kick") || sub.equals("admin")) {
                    for (Player pl : Bukkit.getOnlinePlayers()) out.add(pl.getName());
                }
            }
        } else if (name.equals("home") || name.equals("delhome")) {
            if (sender instanceof Player p && args.length == 1) {
                out.addAll(homes.getOrDefault(p.getUniqueId(), Map.of()).keySet());
            }
        } else if (name.equals("neta") && args.length == 1) {
            for (Player pl : Bukkit.getOnlinePlayers()) out.add(pl.getName());
        }
        return out;
    }

    // ---------------- Homes ----------------

    private int maxHomesFor(Player p) {
        return netas.contains(p.getUniqueId()) ? netaMaxHomes : maxHomes;
    }

    private void setHome(Player p, String[] args) {
        String name = args.length > 0 ? args[0] : "home";
        if (!HOME_NAME.matcher(name).matches()) {
            p.sendMessage("§c[Home] Home name sirf letters, numbers, _ ya - (max 16) ho sakta hai.");
            return;
        }
        Map<String, Home> m = homes.computeIfAbsent(p.getUniqueId(), k -> new LinkedHashMap<>());
        boolean bypass = p.hasPermission("survivalplus.bypass");
        int limit = bypass ? Integer.MAX_VALUE : maxHomesFor(p);
        if (!m.containsKey(name) && m.size() >= limit) {
            p.sendMessage("§c[Home] Tum sirf " + limit + " homes set kar sakte ho! Pehle /delhome <name> se ek delete karo.");
            return;
        }
        m.put(name, Home.of(p.getLocation()));
        saveData();
        p.sendMessage("§e[Home] Home '" + name + "' set ho gaya! (" + m.size() + "/" + (bypass ? "unlimited" : String.valueOf(limit)) + ")");
    }

    private void goHome(Player p, String[] args) {
        UUID id = p.getUniqueId();
        Map<String, Home> mine = homes.getOrDefault(id, Map.of());
        TeamData team = teamOf(id);

        if (args.length == 0) {
            listHomes(p);
            return;
        }
        String name = args[0];
        Home h = mine.get(name);
        if (h == null && team != null) h = team.homes.get(name);
        if (h == null) {
            p.sendMessage("§c[Home] Home '" + name + "' nahi mila. Homes: " + allHomeNames(p));
            return;
        }

        boolean bypass = p.hasPermission("survivalplus.bypass");
        long now = System.currentTimeMillis();
        if (!bypass) {
            Long last = lastHome.get(id);
            if (last != null && now - last < cooldownMs) {
                p.sendMessage("§c[Home] Abhi /home use nahi kar sakte. " + formatDuration(cooldownMs - (now - last)) + " baad try karo.");
                return;
            }
        }

        World w = Bukkit.getWorld(h.world());
        if (w == null) {
            p.sendMessage("§c[Home] Us home ki world load nahi hai.");
            return;
        }
        p.teleport(h.toLocation(w));
        if (!bypass) {
            lastHome.put(id, now);
            saveData();
        }
        p.sendMessage("§a[Home] Home '" + name + "' pe teleport ho gaye!");
    }

    private void delHome(Player p, String[] args) {
        if (args.length == 0) {
            p.sendMessage("§c[Home] Use: /delhome <name>");
            return;
        }
        Map<String, Home> m = homes.get(p.getUniqueId());
        if (m == null || m.remove(args[0]) == null) {
            p.sendMessage("§c[Home] Home '" + args[0] + "' nahi mila.");
            return;
        }
        saveData();
        p.sendMessage("§e[Home] Home '" + args[0] + "' delete ho gaya.");
    }

    private void listHomes(Player p) {
        UUID id = p.getUniqueId();
        boolean bypass = p.hasPermission("survivalplus.bypass");
        Map<String, Home> mine = homes.getOrDefault(id, Map.of());
        TeamData team = teamOf(id);

        p.sendMessage("§6[Homes] §ePersonal (" + mine.size() + "/" + (bypass ? "unlimited" : String.valueOf(maxHomesFor(p))) + "): §f"
                + (mine.isEmpty() ? "koi nahi" : String.join(", ", mine.keySet())));
        if (team != null) {
            p.sendMessage("§6[Homes] §eTeam " + team.color + team.name + "§e (" + team.homes.size() + "/" + teamMaxHomes + "): §f"
                    + (team.homes.isEmpty() ? "koi nahi" : String.join(", ", team.homes.keySet())));
        }
        if (bypass) {
            p.sendMessage("§a[Home] Aapke paas bypass hai, /home ka cooldown nahi lagta.");
        } else {
            Long last = lastHome.get(id);
            long now = System.currentTimeMillis();
            if (last == null || now - last >= cooldownMs) {
                p.sendMessage("§a[Home] /home ab use kar sakte ho.");
            } else {
                p.sendMessage("§c[Home] Agla /home: " + formatDuration(cooldownMs - (now - last)) + " baad.");
            }
        }
    }

    private String allHomeNames(Player p) {
        List<String> names = new ArrayList<>(homes.getOrDefault(p.getUniqueId(), Map.of()).keySet());
        TeamData t = teamOf(p.getUniqueId());
        if (t != null) names.addAll(t.homes.keySet());
        return names.isEmpty() ? "koi nahi" : String.join(", ", names);
    }

    private static String formatDuration(long ms) {
        long totalSec = Math.max(0, (ms + 999) / 1000);
        long min = totalSec / 60;
        long sec = totalSec % 60;
        return min + " min " + sec + " sec";
    }

    // ---------------- Indicator / NightVision / EC ----------------

    private void cmdIndicator(Player p, String[] args) {
        Boolean on = parseSwitch(args);
        if (on == null) {
            p.sendMessage("§c[Indicator] Use: /indicator true  ya  /indicator false");
            return;
        }
        if (on) {
            viewers.add(p.getUniqueId());
            p.sendMessage("§a[Indicator] ON → §7Ab tumhe hearts aur hotbar dikhenge.");
        } else {
            viewers.remove(p.getUniqueId());
            p.sendMessage("§c[Indicator] OFF → §7Ab kuch nahi dikhega.");
        }
        savePlayers();
    }

    private void cmdNightVision(Player p, String[] args) {
        Boolean on = parseSwitch(args);
        if (on == null) {
            p.sendMessage("§c[NightVision] Use: /nightvision true  ya  /nightvision false");
            return;
        }
        if (on) {
            nvPlayers.add(p.getUniqueId());
            giveNightVision(p);
            p.sendMessage("§a[NightVision] ON → §7Ab hamesha full brightness rahegi.");
        } else {
            nvPlayers.remove(p.getUniqueId());
            p.removePotionEffect(PotionEffectType.NIGHT_VISION);
            p.sendMessage("§c[NightVision] OFF → §7Ab normal brightness.");
        }
        savePlayers();
    }

    private static Boolean parseSwitch(String[] args) {
        if (args.length == 0) return null;
        return switch (args[0].toLowerCase(Locale.ROOT)) {
            case "true", "on", "yes" -> Boolean.TRUE;
            case "false", "off", "no" -> Boolean.FALSE;
            default -> null;
        };
    }

    private void giveNightVision(Player p) {
        p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 400, 0, false, false, false));
    }

    private void nightVisionTick() {
        for (UUID u : nvPlayers) {
            Player p = Bukkit.getPlayer(u);
            if (p != null) giveNightVision(p);
        }
    }

    private void cmdEc(Player p) {
        if (!netas.contains(p.getUniqueId()) && !p.isOp()) {
            p.sendMessage("§c[EC] Ye sirf Neta ke liye hai.");
            return;
        }
        p.openInventory(p.getEnderChest());
    }

    // ---------------- Neta / Discord ----------------

    private void handleNeta(CommandSender sender, String[] args) {
        if (!sender.isOp()) {
            sender.sendMessage("§c[Neta] Ye command sirf OP ke liye hai.");
            return;
        }
        if (args.length < 1) {
            sender.sendMessage("§c[Neta] Use: /neta <player>  (dobara likho to Neta hat jayega)");
            return;
        }
        Player t = Bukkit.getPlayerExact(args[0]);
        if (t == null) {
            sender.sendMessage("§c[Neta] Player online nahi hai: " + args[0]);
            return;
        }
        UUID id = t.getUniqueId();
        if (netas.remove(id)) {
            t.sendMessage("§c[Neta] Tumhara Neta rank hata diya gaya.");
            sender.sendMessage("§e[Neta] " + t.getName() + " ka Neta rank hata diya.");
        } else {
            netas.add(id);
            t.sendMessage("§a[Neta] Ab tum §cNeta §ahoo! §7/ec, " + netaMaxHomes + " homes milte hain.");
            sender.sendMessage("§a[Neta] " + t.getName() + " ab §cNeta §ahai!");
        }
        refreshPlayer(t);
        savePlayers();
    }

    private void handleDiscordLink(CommandSender sender, String[] args) {
        String current = getConfig().getString("discord-link", DISCORD_DEFAULT);
        if (args.length == 0) {
            sender.sendMessage("§9[Discord] " + current);
            return;
        }
        if (!sender.isOp()) {
            sender.sendMessage("§c[Discord] Link sirf OP players change kar sakte hain.");
            return;
        }
        String link = args[0];
        if (!link.startsWith("https://")) {
            sender.sendMessage("§c[Discord] Use: /discordlink <https://...link>");
            return;
        }
        getConfig().set("discord-link", link);
        saveConfig();
        sender.sendMessage("§a[Discord] Link set ho gaya: " + link);
    }

    // =====================================================================
    //  Teams
    // =====================================================================

    private void createTeam(Player p, String[] args) {
        if (args.length < 1) {
            p.sendMessage("§c[Team] Use: /createteam <name>  (3-12 letters, numbers ya _)");
            return;
        }
        UUID id = p.getUniqueId();
        if (teamOf(id) != null) {
            p.sendMessage("§c[Team] Tum pehle se team me ho. Pehle /team leave karo.");
            return;
        }
        String name = args[0];
        if (!TEAM_NAME.matcher(name).matches()) {
            p.sendMessage("§c[Team] Team name 3-12 characters ka ho, sirf letters, numbers ya _.");
            return;
        }
        String key = name.toLowerCase(Locale.ROOT);
        if (teams.containsKey(key)) {
            p.sendMessage("§c[Team] Ye team name pehle se hai.");
            return;
        }
        TeamData t = new TeamData(name, id.toString());
        t.members.add(id.toString());
        teams.put(key, t);
        playerTeam.put(id, key);
        saveData();
        refreshPlayer(p);
        p.sendMessage("§a[Team] Team " + t.color + name + " §abana diya! Tum owner ho. /team help dekho.");
    }

    private void handleTeam(Player p, String[] args) {
        if (args.length == 0) {
            sendTeamHelp(p);
            return;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "help" -> sendTeamHelp(p);
            case "info" -> teamInfo(p, args);
            case "invite" -> invite(p, args);
            case "accept" -> accept(p);
            case "leave" -> leave(p);
            case "kick" -> kick(p, args);
            case "disband" -> disband(p, args);
            case "color", "colour" -> setColor(p, args);
            case "admin" -> toggleAdmin(p, args);
            case "enderchest", "ec" -> openChest(p);
            case "sethome" -> teamSetHome(p, args);
            case "delhome" -> teamDelHome(p, args);
            case "ally" -> toggleAlly(p, args);
            default -> sendTeamHelp(p);
        }
    }

    private void sendTeamHelp(Player p) {
        p.sendMessage("§6========== Team Commands ==========");
        p.sendMessage("§e/createteam <name> §7- naya team banao (tum owner ho)");
        p.sendMessage("§e/team info [team] §7- team ki jaankari");
        p.sendMessage("§e/team invite <player> §7- player ko invite karo (owner/admin)");
        p.sendMessage("§e/team accept §7- invite accept karo");
        p.sendMessage("§e/team leave §7- team chhodo");
        p.sendMessage("§e/team kick <player> §7- member ko nikaalo (owner/admin)");
        p.sendMessage("§e/team color <color> §7- team ka color badlo (owner/admin)");
        p.sendMessage("§e/team admin <player> §7- admin banao ya hatao (sirf owner)");
        p.sendMessage("§e/team enderchest §7- team ka shared enderchest kholo");
        p.sendMessage("§e/team sethome <name> §7- team home set karo (owner/admin)");
        p.sendMessage("§e/team delhome <name> §7- team home delete karo (owner/admin)");
        p.sendMessage("§e/team ally <team> §7- doosre team se ally / unally (owner/admin)");
        p.sendMessage("§e/team disband confirm §7- team khatam karo (sirf owner)");
        p.sendMessage("§e/home <name> §7- personal ya team home pe jao");
        p.sendMessage("§6====================================");
    }

    private void teamInfo(Player p, String[] args) {
        TeamData t = args.length > 1 ? teams.get(args[1].toLowerCase(Locale.ROOT)) : teamOf(p.getUniqueId());
        if (t == null) {
            p.sendMessage("§c[Team] Team nahi mila. Tum kisi team me nahi ho ya naam galat hai.");
            return;
        }
        p.sendMessage("§6[Team] " + t.color + ChatColor.BOLD + t.name);
        p.sendMessage("§7Owner: §f" + nameOf(t.owner));
        List<String> adm = new ArrayList<>();
        for (String a : t.admins) adm.add(nameOf(a));
        p.sendMessage("§7Admins: §f" + (adm.isEmpty() ? "koi nahi" : String.join(", ", adm)));
        List<String> mem = new ArrayList<>();
        for (String m : t.members) mem.add(nameOf(m));
        p.sendMessage("§7Members (" + t.members.size() + "): §f" + String.join(", ", mem));
        List<String> al = new ArrayList<>();
        for (String a : t.allies) {
            TeamData o = teams.get(a);
            if (o != null) al.add(o.color + o.name);
        }
        p.sendMessage("§7Allies: §f" + (al.isEmpty() ? "koi nahi" : String.join(", ", al)));
        p.sendMessage("§7Team homes: §f" + (t.homes.isEmpty() ? "koi nahi" : String.join(", ", t.homes.keySet())));
    }

    private void invite(Player p, String[] args) {
        TeamData t = teamOf(p.getUniqueId());
        if (t == null) { p.sendMessage("§c[Team] Tum kisi team me nahi ho."); return; }
        if (!canManage(p.getUniqueId(), t)) { p.sendMessage("§c[Team] Sirf owner ya admin invite kar sakta hai."); return; }
        if (args.length < 2) { p.sendMessage("§c[Team] Use: /team invite <player>"); return; }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) { p.sendMessage("§c[Team] Player online nahi hai."); return; }
        if (teamOf(target.getUniqueId()) != null) { p.sendMessage("§c[Team] " + target.getName() + " pehle se kisi team me hai."); return; }
        invites.put(target.getUniqueId(), new Invite(t.key, System.currentTimeMillis()));
        target.sendMessage("§a[Team] " + t.color + t.name + " §ateam ne tumhe invite kiya hai. §e/team accept §a(60 sec me)");
        p.sendMessage("§a[Team] " + target.getName() + " ko invite bhej diya.");
    }

    private void accept(Player p) {
        UUID id = p.getUniqueId();
        Invite inv = invites.remove(id);
        if (inv == null || System.currentTimeMillis() - inv.at() > INVITE_TTL_MS) {
            p.sendMessage("§c[Team] Koi valid invite nahi hai.");
            return;
        }
        if (teamOf(id) != null) { p.sendMessage("§c[Team] Tum pehle se team me ho."); return; }
        TeamData t = teams.get(inv.teamKey());
        if (t == null) { p.sendMessage("§c[Team] Wo team ab exist nahi karti."); return; }
        t.members.add(id.toString());
        playerTeam.put(id, t.key);
        saveData();
        refreshTeam(t);
        p.sendMessage("§a[Team] Tum ab " + t.color + t.name + " §ame ho!");
        notifyTeam(t, "§a[Team] " + p.getName() + " team me join hua.");
    }

    private void leave(Player p) {
        UUID id = p.getUniqueId();
        TeamData t = teamOf(id);
        if (t == null) { p.sendMessage("§c[Team] Tum kisi team me nahi ho."); return; }
        if (t.owner.equals(id.toString())) {
            p.sendMessage("§c[Team] Tum owner ho. Team khatam karne ke liye /team disband confirm use karo.");
            return;
        }
        removeFromTeam(t, id);
        saveData();
        p.sendMessage("§e[Team] Tumne team chhod diya.");
        notifyTeam(t, "§e[Team] " + p.getName() + " team chhod gaya.");
    }

    private void kick(Player p, String[] args) {
        UUID id = p.getUniqueId();
        TeamData t = teamOf(id);
        if (t == null) { p.sendMessage("§c[Team] Tum kisi team me nahi ho."); return; }
        if (!canManage(id, t)) { p.sendMessage("§c[Team] Sirf owner ya admin kick kar sakta hai."); return; }
        if (args.length < 2) { p.sendMessage("§c[Team] Use: /team kick <player>"); return; }
        String targetUuid = findMember(t, args[1]);
        if (targetUuid == null) { p.sendMessage("§c[Team] Ye player team me nahi hai."); return; }
        if (targetUuid.equals(t.owner) || targetUuid.equals(id.toString())) { p.sendMessage("§c[Team] Owner ko kick nahi kar sakte."); return; }
        if (!isOwner(id, t) && t.admins.contains(targetUuid)) { p.sendMessage("§c[Team] Admin ko sirf owner kick kar sakta hai."); return; }
        UUID tu = UUID.fromString(targetUuid);
        removeFromTeam(t, tu);
        saveData();
        Player tp = Bukkit.getPlayer(tu);
        if (tp != null) tp.sendMessage("§c[Team] Tumhe team se nikaal diya gaya.");
        notifyTeam(t, "§e[Team] " + args[1] + " ko team se nikaala gaya.");
    }

    private void disband(Player p, String[] args) {
        UUID id = p.getUniqueId();
        TeamData t = teamOf(id);
        if (t == null) { p.sendMessage("§c[Team] Tum kisi team me nahi ho."); return; }
        if (!isOwner(id, t)) { p.sendMessage("§c[Team] Sirf owner team khatam kar sakta hai."); return; }
        if (args.length < 2 || !args[1].equalsIgnoreCase("confirm")) {
            p.sendMessage("§c[Team] Pakka khatam karne ke liye: /team disband confirm");
            return;
        }
        notifyTeam(t, "§c[Team] Team " + t.name + " khatam kar diya gaya.");
        for (String m : new ArrayList<>(t.members)) {
            UUID u = parseUuid(m);
            if (u != null) playerTeam.remove(u);
        }
        for (String a : t.allies) {
            TeamData o = teams.get(a);
            if (o != null) o.allies.remove(t.key);
        }
        if (t.chestInv != null) {
            for (HumanEntity he : new ArrayList<>(t.chestInv.getViewers())) he.closeInventory();
        }
        Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
        org.bukkit.scoreboard.Team st = sb.getTeam(SB_PREFIX + t.key);
        if (st != null) st.unregister();
        teams.remove(t.key);
        saveData();
        for (String m : t.members) {
            UUID u = parseUuid(m);
            Player mp = u == null ? null : Bukkit.getPlayer(u);
            if (mp != null) refreshPlayer(mp);
        }
    }

    private void setColor(Player p, String[] args) {
        UUID id = p.getUniqueId();
        TeamData t = teamOf(id);
        if (t == null) { p.sendMessage("§c[Team] Tum kisi team me nahi ho."); return; }
        if (!canManage(id, t)) { p.sendMessage("§c[Team] Sirf owner ya admin team ka color badal sakta hai."); return; }
        if (args.length < 2) {
            p.sendMessage("§c[Team] Use: /team color <color>  (red, blue, gold, aqua, green, yellow, white, ...)");
            return;
        }
        ChatColor c = parseColor(args[1]);
        if (c == null) {
            p.sendMessage("§c[Team] Ye color valid nahi hai. Use: red, dark_blue, gold, aqua, green, ...");
            return;
        }
        t.color = c;
        saveData();
        refreshTeam(t);
        p.sendMessage("§a[Team] Team ka color ab " + c + c.name().toLowerCase(Locale.ROOT) + " §ahai.");
    }

    private void toggleAdmin(Player p, String[] args) {
        UUID id = p.getUniqueId();
        TeamData t = teamOf(id);
        if (t == null) { p.sendMessage("§c[Team] Tum kisi team me nahi ho."); return; }
        if (!isOwner(id, t)) { p.sendMessage("§c[Team] Sirf owner admin bana ya hata sakta hai."); return; }
        if (args.length < 2) { p.sendMessage("§c[Team] Use: /team admin <player>"); return; }
        String targetUuid = findMember(t, args[1]);
        if (targetUuid == null) { p.sendMessage("§c[Team] Ye player team me nahi hai."); return; }
        if (targetUuid.equals(t.owner)) { p.sendMessage("§c[Team] Owner ko admin ki zarurat nahi."); return; }
        if (t.admins.remove(targetUuid)) {
            p.sendMessage("§e[Team] " + args[1] + " ab admin nahi hai.");
        } else {
            t.admins.add(targetUuid);
            p.sendMessage("§a[Team] " + args[1] + " ab team admin hai.");
        }
        saveData();
        refreshTeam(t);
    }

    private void openChest(Player p) {
        TeamData t = teamOf(p.getUniqueId());
        if (t == null) { p.sendMessage("§c[Team] Tum kisi team me nahi ho."); return; }
        p.openInventory(chestOf(t));
    }

    private void teamSetHome(Player p, String[] args) {
        UUID id = p.getUniqueId();
        TeamData t = teamOf(id);
        if (t == null) { p.sendMessage("§c[Team] Tum kisi team me nahi ho."); return; }
        if (!canManage(id, t)) { p.sendMessage("§c[Team] Sirf owner ya admin team home set kar sakta hai."); return; }
        String name = args.length > 1 ? args[1] : "home";
        if (!HOME_NAME.matcher(name).matches()) {
            p.sendMessage("§c[Team] Home name sirf letters, numbers, _ ya - (max 16) ho sakta hai.");
            return;
        }
        if (!t.homes.containsKey(name) && t.homes.size() >= teamMaxHomes) {
            p.sendMessage("§c[Team] Team sirf " + teamMaxHomes + " homes rakh sakta hai. Pehle /team delhome <name> karo.");
            return;
        }
        t.homes.put(name, Home.of(p.getLocation()));
        saveData();
        p.sendMessage("§a[Team] Team home '" + name + "' set ho gaya! (" + t.homes.size() + "/" + teamMaxHomes + ")");
        notifyTeam(t, "§e[Team] " + p.getName() + " ne team home '" + name + "' set kiya. Members /home " + name + " karke jaa sakte hain.");
    }

    private void teamDelHome(Player p, String[] args) {
        UUID id = p.getUniqueId();
        TeamData t = teamOf(id);
        if (t == null) { p.sendMessage("§c[Team] Tum kisi team me nahi ho."); return; }
        if (!canManage(id, t)) { p.sendMessage("§c[Team] Sirf owner ya admin team home delete kar sakta hai."); return; }
        if (args.length < 2 || t.homes.remove(args[1]) == null) {
            p.sendMessage("§c[Team] Team home nahi mila. Use: /team delhome <name>");
            return;
        }
        saveData();
        p.sendMessage("§e[Team] Team home '" + args[1] + "' delete ho gaya.");
    }

    private void toggleAlly(Player p, String[] args) {
        UUID id = p.getUniqueId();
        TeamData t = teamOf(id);
        if (t == null) { p.sendMessage("§c[Team] Tum kisi team me nahi ho."); return; }
        if (!canManage(id, t)) { p.sendMessage("§c[Team] Sirf owner ya admin ally bana sakta hai."); return; }
        if (args.length < 2) { p.sendMessage("§c[Team] Use: /team ally <team>"); return; }
        String otherKey = args[1].toLowerCase(Locale.ROOT);
        TeamData o = teams.get(otherKey);
        if (o == null) { p.sendMessage("§c[Team] Wo team nahi mili."); return; }
        if (o == t) { p.sendMessage("§c[Team] Apne hi team se ally nahi ho sakte."); return; }
        if (t.allies.contains(o.key)) {
            t.allies.remove(o.key);
            o.allies.remove(t.key);
            p.sendMessage("§e[Team] " + o.name + " se ally khatam.");
        } else {
            t.allies.add(o.key);
            o.allies.add(t.key);
            p.sendMessage("§a[Team] " + o.name + " ke saath ally ban gaye!");
            notifyTeam(o, "§a[Team] " + t.name + " team ne tumhare saath ally banaya.");
        }
        saveData();
    }

    // ---------------- Team helpers ----------------

    private TeamData teamOf(UUID id) {
        String k = playerTeam.get(id);
        return k == null ? null : teams.get(k);
    }

    private static boolean isOwner(UUID id, TeamData t) {
        return t.owner.equals(id.toString());
    }

    private static boolean canManage(UUID id, TeamData t) {
        return isOwner(id, t) || t.admins.contains(id.toString());
    }

    private void removeFromTeam(TeamData t, UUID id) {
        t.members.remove(id.toString());
        t.admins.remove(id.toString());
        playerTeam.remove(id);
        Player p = Bukkit.getPlayer(id);
        if (p != null) refreshPlayer(p);
    }

    private String findMember(TeamData t, String name) {
        for (String m : t.members) {
            UUID u = parseUuid(m);
            if (u == null) continue;
            String n = Bukkit.getOfflinePlayer(u).getName();
            if (n != null && n.equalsIgnoreCase(name)) return m;
        }
        return null;
    }

    private String nameOf(String uuid) {
        UUID u = parseUuid(uuid);
        if (u == null) return "?";
        String n = Bukkit.getOfflinePlayer(u).getName();
        return n == null ? "?" : n;
    }

    private void notifyTeam(TeamData t, String message) {
        for (String m : t.members) {
            UUID u = parseUuid(m);
            Player p = u == null ? null : Bukkit.getPlayer(u);
            if (p != null) p.sendMessage(message);
        }
    }

    private void refreshTeam(TeamData t) {
        for (String m : t.members) {
            UUID u = parseUuid(m);
            Player p = u == null ? null : Bukkit.getPlayer(u);
            if (p != null) refreshPlayer(p);
        }
    }

    private static ChatColor parseColor(String s) {
        String k = s.toUpperCase(Locale.ROOT).replace(' ', '_').replace('-', '_');
        try {
            ChatColor c = ChatColor.valueOf(k);
            return c.isColor() ? c : null;
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    private Inventory chestOf(TeamData t) {
        if (t.chestInv == null) {
            TeamChestHolder holder = new TeamChestHolder();
            Inventory inv = Bukkit.createInventory(holder, 54, "§6Team: " + t.name);
            holder.inv = inv;
            if (t.chest != null) inv.setContents(t.chest);
            t.chestInv = inv;
        }
        return t.chestInv;
    }

    /** Naam ke saamne team ka prefix, nametag/tab/chat sab jagah. */
    private void refreshPlayer(Player p) {
        UUID id = p.getUniqueId();
        TeamData t = teamOf(id);
        StringBuilder pre = new StringBuilder();
        if (netas.contains(id)) pre.append(NETA_PREFIX);
        if (t != null) {
            pre.append(t.color).append(ChatColor.BOLD).append('[').append(t.name).append("] ").append(ChatColor.RESET);
        }
        String prefixed = pre + p.getName();
        p.setDisplayName(prefixed);
        p.setPlayerListName(prefixed);
        syncScoreboard(p, t);
    }

    private void syncScoreboard(Player p, TeamData t) {
        Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
        for (org.bukkit.scoreboard.Team st : sb.getTeams()) {
            if (st.getName().startsWith(SB_PREFIX)) st.removeEntry(p.getName());
        }
        if (t == null) return;
        org.bukkit.scoreboard.Team st = sb.getTeam(SB_PREFIX + t.key);
        if (st == null) st = sb.registerNewTeam(SB_PREFIX + t.key);
        st.setColor(t.color);
        st.setPrefix(t.color + "" + ChatColor.BOLD + "[" + t.name + "] " + ChatColor.RESET);
        st.addEntry(p.getName());
    }

    // =====================================================================
    //  Events
    // =====================================================================

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (nvPlayers.contains(p.getUniqueId())) giveNightVision(p);
        // Naye join hue player ko purane HUD displays hide karne hain
        for (Holder h : holders.values()) p.hideEntity(this, h.display);
        refreshPlayer(p);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        invites.remove(id);
        for (Holder h : holders.values()) h.shown.remove(id);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onChat(AsyncPlayerChatEvent e) {
        // Display name me team prefix already hota hai, default format use hota hai
        String msg = e.getMessage().toLowerCase(Locale.ROOT);
        if (msg.contains("discord")) {
            String link = getConfig().getString("discord-link", DISCORD_DEFAULT);
            Bukkit.getScheduler().runTask(this, () ->
                    Bukkit.broadcastMessage("§9[Discord] §b" + link));
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent e) {
        if (e.getInventory().getHolder() instanceof TeamChestHolder) saveData();
    }

    // =====================================================================
    //  HUD (hearts / hotbar indicator)
    // =====================================================================

    private void hudTick() {
        List<Player> vs = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (viewers.contains(p.getUniqueId())) vs.add(p);
        }
        if (vs.isEmpty()) {
            removeAllHolders();
            return;
        }

        Map<UUID, LivingEntity> targets = new LinkedHashMap<>();
        for (Player v : vs) {
            for (Entity e : v.getNearbyEntities(radius, radius, radius)) {
                if (!(e instanceof LivingEntity le)) continue;
                boolean isPlayer = le instanceof Player;
                if (isPlayer ? !showPlayerHearts : !showMobHearts) continue;
                targets.putIfAbsent(le.getUniqueId(), le);
            }
        }

        Set<String> alive = new HashSet<>();
        for (LivingEntity t : targets.values()) {
            boolean isPlayer = t instanceof Player;
            double max = maxHealth(t);
            if (!isPlayer && onlyDamaged && t.getHealth() >= max) continue;

            String hk = t.getUniqueId() + "H";
            alive.add(hk);
            Location base = t.getLocation();
            upsertHolder(hk, base.clone().add(0, isPlayer ? playerHeartsY : mobHeartsY, 0),
                    heartsText(t.getHealth(), max), vs, t);

            if (isPlayer && showHotbar) {
                String bk = t.getUniqueId() + "B";
                alive.add(bk);
                upsertHolder(bk, base.clone().add(0, hotbarY, 0), hotbarText((Player) t), vs, t);
            }
        }

        Iterator<Map.Entry<String, Holder>> it = holders.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Holder> en = it.next();
            if (!alive.contains(en.getKey())) {
                en.getValue().display.remove();
                it.remove();
            }
        }
    }

    private void upsertHolder(String key, Location loc, String text, List<Player> vs, LivingEntity target) {
        Holder h = holders.get(key);
        if (h == null || !h.display.isValid()) {
            World w = loc.getWorld();
            if (w == null) return;
            TextDisplay td = w.spawn(loc, TextDisplay.class, d -> {
                d.addScoreboardTag(TAG);
                d.setPersistent(false);
                d.setBillboard(Display.Billboard.CENTER);
            });
            for (Player p : Bukkit.getOnlinePlayers()) p.hideEntity(this, td);
            h = new Holder(td);
            holders.put(key, h);
        }
        h.display.teleport(loc);
        h.display.text(LegacyComponentSerializer.legacySection().deserialize(text));

        double r2 = radius * radius;
        for (Player v : vs) {
            UUID vid = v.getUniqueId();
            boolean want = !vid.equals(target.getUniqueId())
                    && v.getWorld().equals(loc.getWorld())
                    && v.getLocation().distanceSquared(target.getLocation()) <= r2
                    && looking(v, target);
            if (want && h.shown.add(vid)) {
                v.showEntity(this, h.display);
            } else if (!want && h.shown.remove(vid)) {
                v.hideEntity(this, h.display);
            }
        }
    }

    private boolean looking(Player v, LivingEntity t) {
        Vector to = t.getEyeLocation().toVector().subtract(v.getEyeLocation().toVector());
        if (to.lengthSquared() < 1e-6) return true;
        return v.getEyeLocation().getDirection().dot(to.normalize()) >= viewRange;
    }

    private static double maxHealth(LivingEntity t) {
        var attr = t.getAttribute(Attribute.MAX_HEALTH);
        return attr == null ? t.getHealth() : attr.getValue();
    }

    private static String heartsText(double hp, double max) {
        return String.format(Locale.US, "§c❤ §f%.1f§7/%.0f", hp, max);
    }

    private static String hotbarText(Player p) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 9; i++) {
            ItemStack it = p.getInventory().getItem(i);
            if (it == null || it.getType().isAir()) sb.append("§8. ");
            else sb.append("§f").append(it.getAmount()).append(' ');
        }
        return sb.toString().trim();
    }

    private void removeAllHolders() {
        for (Holder h : holders.values()) h.display.remove();
        holders.clear();
    }

    private void cleanupStray() {
        for (World w : Bukkit.getWorlds()) {
            for (TextDisplay td : w.getEntitiesByClass(TextDisplay.class)) {
                if (td.getScoreboardTags().contains(TAG)) td.remove();
            }
        }
    }

    private static final class Holder {
        final TextDisplay display;
        final Set<UUID> shown = new HashSet<>();
        Holder(TextDisplay display) { this.display = display; }
    }

    // =====================================================================
    //  Data types
    // =====================================================================

    /** Ek home ki location. World naam store hota hai taaki world load na hone par bhi data na jaye. */
    public record Home(String world, double x, double y, double z, float yaw, float pitch) {
        static Home of(Location l) {
            return new Home(l.getWorld().getName(), l.getX(), l.getY(), l.getZ(), l.getYaw(), l.getPitch());
        }
        Location toLocation(World w) {
            return new Location(w, x, y, z, yaw, pitch);
        }
    }

    private record Invite(String teamKey, long at) {}

    private static final class TeamData {
        final String name;
        final String key;
        String owner;
        ChatColor color = ChatColor.WHITE;
        final Set<String> members = new LinkedHashSet<>();
        final Set<String> admins = new LinkedHashSet<>();
        final Set<String> allies = new LinkedHashSet<>();
        final Map<String, Home> homes = new LinkedHashMap<>();
        ItemStack[] chest;      // saved contents (load ke baad)
        Inventory chestInv;     // live inventory (jab koi khole)

        TeamData(String name, String owner) {
            this.name = name;
            this.key = name.toLowerCase(Locale.ROOT);
            this.owner = owner;
        }

        ItemStack[] snapshot() {
            return chestInv != null ? chestInv.getContents() : chest;
        }
    }

    private static final class TeamChestHolder implements InventoryHolder {
        Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }
}
